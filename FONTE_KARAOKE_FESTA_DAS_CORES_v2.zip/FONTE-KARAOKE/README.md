# Código-fonte — Karaokê Festa das Cores (v2.0)

Pacote `br.com.ursoplayer.karaoke`. Projeto Android com a tela em HTML/CSS/JavaScript (`app/src/main/assets/index.html`) e a ponte em Java (`MainActivity.java`). A pasta `reference/` guarda o APK 1.6 original.

## Novidades da v2.0

- **Sempre em paisagem** (manifesto `sensorLandscape` + trava no Java e no JavaScript). Celular, tablet e TV usam o mesmo layout.
- **Visual profissional para Smart TV**: palco grande à esquerda, **fila de músicas** à direita, barra inferior com **CÓDIGO · CATÁLOGO · INICIAR SHOW**. Tudo escala pela altura da tela (720p, 1080p, 4K). Fontes maiores e foco amarelo bem visível para o controle remoto.
- **Catálogo na tela**: botão CATÁLOGO lista todas as músicas por letra. No controle: ↑↓ escolhe a música, ←→ troca a letra, OK seleciona, Voltar fecha. Lá dentro também há **TROCAR PASTA**.
- **Lista automática (`lista.txt`)**:
  - O app lembra a pasta escolhida e abre direto nela nas próximas vezes (só pergunta se a pasta sumir).
  - Procura vídeos novos ao abrir, ao voltar para o app e a cada 30 s com o palco parado.
  - Vídeo que já tem número no nome (`0123 - Nome.mp4`) usa esse número.
  - Vídeo sem número é procurado pelo nome no `lista.txt`; se não estiver lá, recebe o **próximo código livre** e a linha `0456 - Nome da Música` é **acrescentada no final** do `lista.txt`. Linhas existentes nunca são alteradas.
  - Funciona com vídeos em subpastas (A, B, C…).
  - Na primeira vez, na tela de escolha de pasta, é preciso **permitir** o acesso. Se a unidade for somente leitura, o app avisa e usa os códigos só na memória.
  - Se o `lista.txt` antigo estiver em ANSI/Windows-1252, ele é lido corretamente e regravado em UTF-8.
- Correção: o "4" de `.mp4` era lido como código de música.

## Compilar o APK

Precisa de Android SDK (Android Studio) ou do GitHub Actions:

```sh
gradle assembleDebug     # Gradle 8.11+ / JDK 17
```

O APK sai em `app/build/outputs/apk/debug/`. Pelo GitHub: envie o **conteúdo** desta pasta para um repositório, abra **Actions → Gerar APK → Run workflow** e baixe o APK em *Artifacts*.

## Assinatura / atualização por cima

O APK de depuração usa uma chave nova e **não atualiza por cima** do app 1.6 instalado: desinstale o antigo antes. Para atualizar por cima, assine com a mesma chave privada do APK original (SHA-256 do certificado: `ad:ba:c2:f7:8a:3c:81:b9:b1:02:eb:fd:cc:e3:79:4b:5e:9d:43:0d:aa:87:4a:0d:20:94:01:7c:02:9f:1c:6a`). A chave privada não está neste pacote.
